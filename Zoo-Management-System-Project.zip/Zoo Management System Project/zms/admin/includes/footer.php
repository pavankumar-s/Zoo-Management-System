<footer>
            <div class="footer-area">
                <p>Zoo Management System @ 2020. All right reserved</p>
            </div>
        </footer>